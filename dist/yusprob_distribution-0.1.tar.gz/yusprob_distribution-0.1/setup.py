from setuptools import setup

setup(name='yusprob_distribution',
      version='0.1',
      description='Gaussian  and Bionomial distributions',
      packages=['yusprob_distribution'],
      author='Yusuf Abubakar',
      author_email='uoooosuf@gmail.com',
      zip_safe=False)
